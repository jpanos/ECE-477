 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\UltraLibrarian\Library\Exported\KiCad\2020-09-21_00-06-44\2020-09-21_00-06-44\2020-09-21_00-06-44.lib
 
 
After you have used Ultra Librarian to export library:
**************************************************
**To import your new library symbols into KiCad:**
**************************************************
1. Open KiCad.
2. On the program/tool list, select the Symbol Library Editor.
3. In the Symbol Library Editor, select 'Add an existing library' from the symbol menu or "Add Library" from the File menu.
4. From here select the library you wish to add.
5. Now select if you would like the library accessible globaly or for the current project.
6. Browsing the list of libraries, you should see the newly imported library!

**************************************************************
**To import your new library footprints/patterns into KiCad:**
**************************************************************
1. Open KiCad.
2. On the program/tool list, go to Pcbnew, or simply open the footprint editor.
3. Select the "import footprint" icon then select the *.kicad_mod* file of the footprint to be imported.
4. You have now successfully imported your new footprint/pattern.


**************************************************************
**    !!!!!!!!!!!!!        WARNING        !!!!!!!!!!!!!     **
**************************************************************
KiCAD does not support filled/hatched polygons on footprints!
All polygons will be represented with an outline made of lines in each design.
Etch polygons will be drawn on the documentation layer, "Dwgs.User", and can be filled during board creation.
 
 
